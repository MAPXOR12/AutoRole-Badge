export {Manager} from "./src/Manager"
// eslint-disable-next-line @typescript-eslint/no-var-requires
export const version: string = require(`${__dirname}/../package.json`).version;